# Final

# https://github.com/kgenesherman/final9999

Ken Sherman CSC436

I had a lot of problems with Firebase and NG.  I got working versions that would do authentication and CRUD, but not both together.

This version was built with help from  https://gavilan.blog/2019/06/02/my-first-app-with-angular-8-todo-app-introduction/

The above webpage does not work out of the box.  Had o replace login component with login service.

The final app works for authentication.  There is a routing problem.  Works with manual entry of loc:4200/card-list.
I will commit this and try to fix the routing today.

First commit.

Added firebase cloudstore.

Added components and sertvices.

Added Routing.

Added Authentication and login.

core.js:6014 ERROR Error: Uncaught (in promise): Error: No component factory found for AuthService. Did you add it to @NgModule.entryComponents?
Error: No component factory found for AuthService. Did you add it to @NgModule.entryComponents?

hoever, AuthShervice is a provider, not allowed in entryComponents.



